/* script.js - Option A integrated with prefill and whatsapp */
document.addEventListener('DOMContentLoaded', function(){
  // année footer
  const years = document.querySelectorAll('#year, #year2, #year3, #year4');
  years.forEach(el => { if(el) el.textContent = new Date().getFullYear(); });

  // mobile nav toggle
  const navToggle = document.getElementById('navToggle');
  if(navToggle){
    navToggle.addEventListener('click', () => {
      const nav = document.querySelector('.main-nav');
      if(nav) nav.style.display = (nav.style.display === 'block') ? '' : 'block';
    });
  }

  // INVENTAIRE (Option A : 1 carte par modèle, plage d'années)
  const cars = [
    {
      id: 'mercedes-gle',
      brand: 'Mercedes',
      model: 'GLE',
      years: '2016–2024',
      price: 'Sur demande',
      img: 'images/mercedes_gle.jpg',
      desc: 'SUV premium, disponible sur commande dans différentes motorisations et finitions.'
    },
    {
      id: 'toyota-prado-tx',
      brand: 'Toyota',
      model: 'Prado TX',
      years: '2017–2024',
      price: 'Sur demande',
      img: 'images/toyota_prado_tx.jpg',
      desc: '4x4 robuste idéal pour routes difficiles et usage familial. Options d’importation disponibles.'
    },
    {
      id: 'toyota-rav4',
      brand: 'Toyota',
      model: 'RAV4',
      years: '2012–2019',
      price: 'Sur demande',
      img: 'images/toyota_rav4.jpg',
      desc: 'Compact SUV fiable, options essence/diesel selon l’année.'
    },
    {
      id: 'lexus-rx350',
      brand: 'Lexus',
      model: 'RX 350',
      years: '2015–2024',
      price: 'Sur demande',
      img: 'images/lexus_rx350.jpg',
      desc: 'Berline/SUV de luxe, finition haut de gamme. Idéal pour clients recherchant confort et fiabilité.'
    },
    {
      id: 'lexus-lx570',
      brand: 'Lexus',
      model: 'LX 570',
      years: '2010–2024',
      price: 'Sur demande',
      img: 'images/lexus_lx570.jpg',
      desc: 'Grand SUV de luxe 4x4 — parfait pour importation et usage tout-terrain.'
    },
    {
      id: 'toyota-camry',
      brand: 'Toyota',
      model: 'Camry',
      years: '2012–2024',
      price: 'Sur demande',
      img: 'images/toyota_camry.jpg',
      desc: 'Berline populaire et économique — version essence et hybride disponibles selon l’année.'
    },
    {
      id: 'sur-commande',
      brand: 'Divers',
      model: 'Sur commande',
      years: 'Demande',
      price: 'Sur demande',
      img: 'images/sur_commande.jpg',
      desc: 'Tu veux un modèle qui ne figure pas ici ? Nous l’importons pour toi — indique le modèle et l’année souhaitée.'
    }
  ];

  // If on inventory page: render grid
  const carsGrid = document.getElementById('carsGrid');
  if(carsGrid){
    function render(list){
      carsGrid.innerHTML = '';
      list.forEach(c => {
        const card = document.createElement('article');
        card.className = 'card';
        card.id = c.id;
        card.innerHTML = `
          <img src="${c.img}" alt="${c.brand} ${c.model}">
          <div class="card-body">
            <h4>${c.brand} ${c.model} <span style="font-weight:400;font-size:0.9rem;color:#666">(${c.years})</span></h4>
            <p class="muted">${c.desc}</p>
            <p class="price">${c.price}</p>
            <div style="margin-top:.5rem">
              <a class="btn btn-sm" href="contact.html?interest=${encodeURIComponent(c.id)}">Demander ce véhicule</a>
              <a class="btn btn-sm" style="margin-left:6px" href="https://wa.me/24264595665" target="_blank" rel="noopener">WhatsApp</a>
            </div>
          </div>
        `;
        carsGrid.appendChild(card);
      });
    }

    render(cars);

    // filters simple
    const search = document.getElementById('search');
    const filterBrand = document.getElementById('filterBrand');
    const filterYear = document.getElementById('filterYear');
    const resetFilters = document.getElementById('resetFilters');

    function applyFilters(){
      const q = search.value.trim().toLowerCase();
      const brand = filterBrand.value;
      const year = filterYear.value;
      const filtered = cars.filter(c => {
        const matchQ = q ? (c.brand.toLowerCase().includes(q) || c.model.toLowerCase().includes(q) || c.years.toLowerCase().includes(q)) : true;
        const matchBrand = brand ? c.brand === brand : true;
        const matchYear = year ? (c.years.toString().includes(year)) : true;
        return matchQ && matchBrand && matchYear;
      });
      render(filtered);
    }

    [search, filterBrand, filterYear].forEach(el => { if(el) el.addEventListener('input', applyFilters); });
    if(resetFilters) resetFilters.addEventListener('click', () => {
      if(search) search.value=''; if(filterBrand) filterBrand.value=''; if(filterYear) filterYear.value=''; applyFilters();
    });
  }

  // Newsletter simple (front-end only)
  const newsletterForm = document.getElementById('newsletterForm');
  if(newsletterForm){
    newsletterForm.addEventListener('submit', function(e){
      e.preventDefault();
      const email = document.getElementById('newsletterEmail').value;
      alert('Merci ! ' + email + ' a bien été ajouté à la liste (à connecter à un service réel).');
      newsletterForm.reset();
    });
  }

  // Contact prefill on contact page
  const params = new URLSearchParams(window.location.search);
  const interest = params.get("interest");
  if (interest) {
    const textarea = document.getElementById("message");
    const subject = document.getElementById("subject");
    const prettyName = interest.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
    if (subject) subject.value = "Demande d'information : " + prettyName;
    if (textarea) {
      textarea.value = "Bonjour,\\nJe suis intéressé par ce véhicule : " + prettyName + ".\\nPouvez-vous me donner plus d'informations ?\\n\\nMerci.";
    }
  }
});
